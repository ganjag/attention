# Analysis

## Layer 2, Head 7

Analysis of the relationship between verbs and direct Objects. 

Example Sentences:
- 'She [MASK] the carrot quickly.'
- 'The carrot was [MASK] by her quickly.'

## Layer 6, Head 7

Analysis of the relationship between verbs and prepositions.

Example Sentences:
- 'The cat [MASK] onto the cold, wet counter.'
- 'The grandma walked [MASK] the bridge.'

